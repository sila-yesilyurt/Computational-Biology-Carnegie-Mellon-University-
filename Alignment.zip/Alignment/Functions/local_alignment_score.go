package Functions

//LocalScoreTable takes two strings and alignment penalties. It returns a 2-D array
//holding dynamic programming scores for local alignment with these penalties.
func LocalScoreTable(str0, str1 string, match, mismatch, gap float64) [][]float64 {
	//replace this with your code
	return [][]float64{}
}
