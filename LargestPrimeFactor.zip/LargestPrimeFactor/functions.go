package LargestPrime

//Write a function to find a largest prime number.

//LargestPrimeFactor takes an integer n as input.
//It panics if n < 2. Otherwise, it returns the largest prime
//factor of n.
func LargestPrimeFactor(n int) int {
  //replace this with your code
  return 0
}
