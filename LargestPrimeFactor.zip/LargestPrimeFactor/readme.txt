Copy the LargestPrimeFactor folder into your "go/src" directory.

Then, write each the missing function in functions.go. If you need a subroutine, please feel free to place it in the same file.

To test your function, you can simply "cd" into the LargestPrimeFactor directory and run "go test".